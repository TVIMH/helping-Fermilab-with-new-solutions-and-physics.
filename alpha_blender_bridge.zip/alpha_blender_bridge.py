
import bpy
import json
import os
import math

# === CONFIGURATION ===
json_path = "/home/robert-weber/Documents/AlphaMillenniumProofs/black_hole_formation_anti_matter.json"
object_name = "AlphaSimulationObject"
material_name = "AlphaSimMaterial"
scale_factor = 1.0

# === LOAD JSON DATA ===
if not os.path.exists(json_path):
    raise FileNotFoundError(f"JSON file not found: {json_path}")

with open(json_path, 'r') as f:
    sim_data = json.load(f)

# === EXTRACT GEOMETRY DATA ===
vertices = sim_data.get("vertices", [])
faces = sim_data.get("faces", [])

if not vertices or not faces:
    raise ValueError("JSON missing 'vertices' or 'faces' data.")

# === CREATE MESH ===
mesh = bpy.data.meshes.new(name=object_name + "_Mesh")
obj = bpy.data.objects.new(object_name, mesh)
bpy.context.collection.objects.link(obj)
mesh.from_pydata(vertices, [], faces)
mesh.update()

# === SCALE OBJECT ===
obj.scale = (scale_factor, scale_factor, scale_factor)

# === APPLY BASIC MATERIAL ===
if material_name not in bpy.data.materials:
    mat = bpy.data.materials.new(name=material_name)
    mat.use_nodes = True
else:
    mat = bpy.data.materials[material_name]

if obj.data.materials:
    obj.data.materials[0] = mat
else:
    obj.data.materials.append(mat)

# === ADD CAMERA ===
if "AlphaCam" not in bpy.data.objects:
    cam_data = bpy.data.cameras.new(name="AlphaCam")
    cam_obj = bpy.data.objects.new("AlphaCam", cam_data)
    bpy.context.collection.objects.link(cam_obj)
    cam_obj.location = (5, -5, 5)
    cam_obj.rotation_euler = (math.radians(60), 0, math.radians(45))
    bpy.context.scene.camera = cam_obj

# === ADD LIGHT ===
if "AlphaLight" not in bpy.data.objects:
    light_data = bpy.data.lights.new(name="AlphaLight", type="SUN")
    light_obj = bpy.data.objects.new("AlphaLight", light_data)
    bpy.context.collection.objects.link(light_obj)
    light_obj.location = (10, -10, 10)

print("[BLENDER BRIDGE] Import complete. Render ready.")
